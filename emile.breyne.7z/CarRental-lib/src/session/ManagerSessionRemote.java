package session;

import java.util.Date;
import java.util.List;
import java.util.Set;
import javax.ejb.Remote;
import rental.CarType;
import rental.Reservation;

@Remote
public interface ManagerSessionRemote {
    
    public Set<CarType> getCarTypes(String company);
    
    public Set<Integer> getCarIds(String company,String type);
    
    public int getNumberOfReservations(String company, String type, int carId);
    
    public int getNumberOfReservations(String company, String type);
    
    public List<String> getAllCarRentalCompanies();
    
    public List<CarType> getAllCarTypes(String crc);
    
    public int getNbReservationsOfCarTypeInCrc(String carType, String crc);
    
    /**
    public String getBestClient(String crc);
    */
    
    public CarType getMostPupularCarType(String crc, int year);
    
    public CarType getCheapestCarTypeAvailable(Date startDate, Date endDate, String regions);

    public void setUserName(String name);

    public void setCarRentalCompanyName(String carRentalName);

    public int getNbReservationsBy(String clientName);

    public Set<String> getBestClients();

    public void addCarRentalCompanyData(String[] args);
    
    
    
       
}