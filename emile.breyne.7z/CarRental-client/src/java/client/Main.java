package client;

import java.util.Date;
import java.util.List;
import java.util.Set;
import javax.ejb.EJB;
import javax.naming.InitialContext;
import rental.CarType;
import rental.Reservation;
import rental.ReservationConstraints;
import rental.ReservationException;
import session.CarRentalSessionRemote;
import session.ManagerSessionRemote;

public class Main extends AbstractTestManagement<CarRentalSessionRemote, ManagerSessionRemote> {
    
    @EJB
    private static CarRentalSessionRemote RentalSession;
    @EJB
    private static ManagerSessionRemote managerSession;

    public Main(String scriptFile) {
        super(scriptFile);
    }

    public static void main(String[] args) throws Exception {
        // TODO: use updated manager interface to load cars into companies
        //The different car rental companies and their properties are given as arguments of the main function and will be processed by the managerSession.
        managerSession.addCarRentalCompanyData(args);
        
        new Main("trips").run();
        
    }

    @Override
    protected Set<String> getBestClients(ManagerSessionRemote ms) throws Exception {
        return ms.getBestClients();
    }

    @Override
    protected String getCheapestCarType(CarRentalSessionRemote session, Date start, Date end, String region) throws Exception {
        return session.getCheapestCarType(start, end, region);
    }

    @Override
    protected CarType getMostPopularCarTypeIn(ManagerSessionRemote ms, String carRentalCompanyName, int year) throws Exception {
        return ms.getMostPupularCarType(carRentalCompanyName, year);
    }

    /*  WAT ALS MEERDERE RENTERS?
    @Override
    protected CarRentalSessionRemote getNewReservationSession(String name) throws Exception {
        session.setRenterName(name);
        return session;
    }
    
    @Override
    protected ManagerSessionRemote getNewManagerSession(String name, String carRentalName) throws Exception {
        managerSession.setUserName(name);
        managerSession.setCarRentalCompanyName(carRentalName);
        return managerSession;
    }
*/
    
    /*
    zie dependency injection
    */
    @Override
    protected CarRentalSessionRemote getNewReservationSession(String name) throws Exception {
        CarRentalSessionRemote out = (CarRentalSessionRemote) (new InitialContext()).lookup(CarRentalSessionRemote.class.getName());
        out.setRenterName(name);
        return out;
    }

    /*
    zie dependency injection
    */
    @Override

    protected ManagerSessionRemote getNewManagerSession(String name, String carRentalName) throws Exception {
        ManagerSessionRemote out = (ManagerSessionRemote) (new InitialContext()).lookup(ManagerSessionRemote.class.getName());
        return out;
    }
    
    @Override
    protected void checkForAvailableCarTypes(CarRentalSessionRemote session, Date start, Date end) throws Exception {
        List<CarType> list = session.getAvailableCarTypes(start, end);
        
        for(CarType ct : list){
            System.out.println(ct.getName());
        }
    }

    
    /**
     * Add a quote for a given car type to the session.
     *
     * @param session the session to add the reservation to
     * @param name the name of the client owning the session
     * @param start start time of the reservation
     * @param end end time of the reservation
     * @param carType type of car to be reserved
     * @param region region for which the car shall be reserved
     * should be done
     *
     * @throws Exception if things go wrong, throw exception
     */
    @Override
    protected void addQuoteToSession(CarRentalSessionRemote session, String name, Date start, Date end, String carType, String region) throws Exception {
        try{session.addQuoteToSession(start, end, carType,region);}
        catch(ReservationException e){
            System.out.println("No cars available to satisfy the given constraints at any Car Rental Company.");
        }
    }

    @Override
    protected List<Reservation> confirmQuotes(CarRentalSessionRemote session, String name) throws Exception {
        return session.confirmQuotes();
        
    }

    @Override
    protected int getNumberOfReservationsBy(ManagerSessionRemote ms, String clientName) throws Exception {
        return ms.getNbReservationsBy(clientName);
    }

    @Override
    protected int getNumberOfReservationsForCarType(ManagerSessionRemote ms, String carRentalName, String carType) throws Exception {
        return ms.getNbReservationsOfCarTypeInCrc(carType, carRentalName);
    }
    
    
}