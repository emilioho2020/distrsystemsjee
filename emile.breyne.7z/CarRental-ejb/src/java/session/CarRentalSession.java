package session;

import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import rental.CarType;
import rental.Quote;
import rental.Reservation;
import rental.ReservationConstraints;
import rental.ReservationException;
import rental.CarRentalCompany;



@Stateful
public class CarRentalSession implements CarRentalSessionRemote {

    private String renter;
    private List<Quote> quotes = new LinkedList<Quote>();

    
    @PersistenceContext
    EntityManager em;
       
    @Override
    public Set<String> getAllRentalCompanies() {
        List<String> list = em.createNamedQuery("findAllCarRentalCompanyNames").getResultList();
        return new HashSet<String>(list);
    }
    
    /*
    Returns all car rental company objects
    used in getAvailableCartypes
    */
    public Set<CarRentalCompany> getAllRentalCompaniesObjects(){
        List<CarRentalCompany> list = em.createNamedQuery("findAllCarRentalCompanies").getResultList();
        return new HashSet<CarRentalCompany>(list);
    }
    
    @Override
    public List<CarType> getAvailableCarTypes(Date start, Date end) {
        List<CarType> availableCarTypes = new LinkedList<CarType>();
        for(CarRentalCompany crc : getAllRentalCompaniesObjects()) {
            for(CarType ct : crc.getAvailableCarTypes(start, end)) {
                if(!availableCarTypes.contains(ct))
                    availableCarTypes.add(ct);
            }
        }
        return availableCarTypes;
    }

    @Override
    public Quote createQuote(String company, ReservationConstraints constraints) throws ReservationException {
        try {
            Quote out = em.find(CarRentalCompany.class,company).createQuote(constraints, renter);
            quotes.add(out);
            return out;
        } catch(Exception e) {
            throw new ReservationException(e);
        }
    }

    @Override
    public List<Quote> getCurrentQuotes() {
        return quotes;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public List<Reservation> confirmQuotes() throws ReservationException {
        List<Reservation> done = new LinkedList<Reservation>();
        try {
            for (Quote quote : quotes) {
                done.add(em.find(CarRentalCompany.class,(quote.getRentalCompany())).confirmQuote(quote));
            }
        } catch (Exception e) {
            for(Reservation r:done)
                em.find(CarRentalCompany.class,(r.getRentalCompany())).cancelReservation(r);
            throw new ReservationException(e);
        }
        return done;
    }

    @Override
    public void setRenterName(String name) {
        if (renter != null) {
            throw new IllegalStateException("name already set");
        }
        renter = name;
    }

    
 
    /*
     * searches for ONE car rental company who satisfies the constraints and creates a quote.
     * Add a quote for a given car type to the session.
     *
     * @param session the session to add the reservation to
     * @param name the name of the client owning the session
     * @param start start time of the reservation
     * @param end end time of the reservation
     * @param carType type of car to be reserved
     * @param region region for which the car shall be reserved
     * should be done
     *
     * @throws Exception if things go wrong, throw exception
     */
    public Quote addQuoteToSession(Date start, Date end, String carType, String region) throws ReservationException{
        ReservationConstraints constr = new ReservationConstraints(start,end,carType,region);
        Quote quot = null;
        for(String crc : getAllRentalCompanies()){
            try{
                quot = em.find(CarRentalCompany.class,crc).createQuote(constr,crc);
                break;}
            catch(ReservationException e){} //try to create quote until one succeeds at one car rental company
        }
        if(quot == null){
        throw new ReservationException("No cars available to satisfy the given constraints at any Car Rental Company.");}
        else return quot;
    }
    
    
    /* FOUT! werkt niet + je moet de cheapest car type AVAILABLE given constraints geven
    @Override
    public String getCheapestCarType(Date start, Date end, String region) {
        
        List list = em.createQuery("SELECT ct.name "
                + "FROM CarRentalCompany crc JOIN crc.carTypes ct JOIN crc.cars car JOIN car.reservations res WHERE (givenRegion IN crc.regions) AND (car.type=ct) AND (givenStart NOT BETEEN res.startDate and res.endDate) "
                + "AND (givenEnd NOT BETEEN res.startDate AND res.endDate) ORDER BY ct.rentalPricePerDayv ASC")
                .setParameter("givenRegion", region).setParameter("givenStart", start).setParameter("givenEnd", end).setMaxResults(1).getResultList();
        
        
        
        return (String) list.get(0);
      
    }
    */
    
    @Override
    public String getCheapestCarType(Date start,Date end,String region){
        try{
            List<String> list = em.createQuery("SELECT DISTINCT ct.name "
                    + "FROM CarRentalCompany crc JOIN crc.carTypes ct JOIN crc.cars car LEFT OUTER JOIN car.reservations res "
                    + "WHERE (:givenRegion IN crc.regions) AND "
                    + "NOT EXISTS( "
                        + "SELECT res "
                        + "FROM car LEFT OUTER JOIN car.reservations res "
                        + "WHERE "
                        + "(car.type = ct) AND "
                        + "((res.startDate < :givenEnd AND res.endDate > :givenEnd) OR "
                        + "(res.endDate > :givenStart AND res.startDate < :givenStart)) "
                    + "ORDER BY ct.rentalPricePerDay ASC")
                    .setParameter("givenRegion", region).setParameter("givenStart", start).setParameter("givenEnd", end).setMaxResults(1).getResultList();


            return list.get(0);}
        catch(Exception e){
            return "DEZE METHODE IS NOG NIET HELEMAAL JUIST";
        }
    }
    
    
}