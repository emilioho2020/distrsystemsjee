package session;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import rental.Car;
import rental.CarRentalCompany;
import rental.CarType;
import rental.RentalStore;
import rental.Reservation;
import rental.ReservationConstraints;

@Stateless
public class ManagerSession implements ManagerSessionRemote {
    
    protected static final DateFormat DATE_FORMAT = new SimpleDateFormat("d/M/y");
    
    @Override
    public Set<CarType> getCarTypes(String company) {
        try {
            return new HashSet<CarType>(RentalStore.getRental(company).getAllTypes());
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(ManagerSession.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public Set<Integer> getCarIds(String company, String type) {
        Set<Integer> out = new HashSet<Integer>();
        try {
            for(Car c: RentalStore.getRental(company).getCars(type)){
                out.add(c.getId());
            }
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(ManagerSession.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return out;
    }

    @Override
    public int getNumberOfReservations(String company, String type, int id) {
        try {
            return RentalStore.getRental(company).getCar(id).getReservations().size();
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(ManagerSession.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }

    @Override
    public int getNumberOfReservations(String company, String type) {
        Set<Reservation> out = new HashSet<Reservation>();
        try {
            for(Car c: RentalStore.getRental(company).getCars(type)){
                out.addAll(c.getReservations());
            }
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(ManagerSession.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
        return out.size();
    }
    
    
    
    @PersistenceContext
    EntityManager em;
    

    @Override
    public void addCarRentalCompanyData(String[] args) {
        
        
        try {
            for(int i = 0; i < args.length; i++){
                RentalStore.loadData(args[i]);
                addCRC(RentalStore.loadData(args[i]).name, RentalStore.loadData(args[i]).regions, RentalStore.loadData(args[i]).cars);
                
                List<CarType> addedCarTypes = new ArrayList<>();
                
                for(Car c : RentalStore.loadData(args[i]).cars){
                    addCar(c.getId(), c.getType());
                    if(!addedCarTypes.contains(c.getType())){
                        addCarType(c.getType().getName(), c.getType().getNbOfSeats(), c.getType().getTrunkSpace(), c.getType().getRentalPricePerDay(), c.getType().isSmokingAllowed());
                        addedCarTypes.add(c.getType());
                    }
                }
            }   
        } catch (NumberFormatException ex) {
            Logger.getLogger(ManagerSession.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ManagerSession.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    public void addCRC(String crcName, List<String> regions, List<Car> cars) {
        
        CarRentalCompany crc = new CarRentalCompany(crcName, regions, cars);
        em.persist(crc);
    }

    public void addCarType(String name, int nbOfSeats, float trunkSpace, double rentalPricePerDay, boolean smokingAllowed) {
        
        CarType ct = new CarType(name, nbOfSeats, trunkSpace, rentalPricePerDay, smokingAllowed);
        em.persist(ct);
    }

    public void addCar(int carId, CarType carType) {
        
        Car car = new Car(carId, carType);
        em.persist(car);
    }

    @Override
    public List<String> getAllCarRentalCompanies() {
        return em.createQuery("SELECT c.name FROM CarRentalCompany c").getResultList();
    }

    
    
    @Override
    public List<CarType> getAllCarTypes(String crcName) {
        
        CarRentalCompany crc = em.find(CarRentalCompany.class, crcName);
        return em.createQuery("SELECT ct FROM CarRentalCompany crc JOIN crc.carTypes ct WHERE crc = :givenCrc").setParameter("givenCrc", crc).getResultList();
        
    }

    @Override
    public int getNbReservationsOfCarTypeInCrc(String carTypeName, String crcName) {
        CarType carType = em.find(CarType.class, carTypeName);
        CarRentalCompany crc = em.find(CarRentalCompany.class, crcName);
        
        List list = em.createQuery("SELECT res FROM CarRentalCompany crc JOIN crc.carTypes ct JOIN crc.cars car JOIN car.reservations res WHERE crc= :givenCrc AND car.type = :givenct AND ct= :givenct")
                .setParameter("givenCrc", crc).setParameter("givenct", carType).getResultList();
        
        return list.size();
    }

    //Moest getBestClients zijn
    /**@Override
    public String getBestClient(String crcName) {
        CarRentalCompany crc = em.find(CarRentalCompany.class, crcName);
        
        List list = em.createQuery("SELECT res.carRenter FROM CarRentalCompany crc JOIN crc.cars car JOIN car.reservations res WHERE crc=givenCrc GROUP BY res.carRenter ORDER BY COUNT(res) DESC").setParameter("givenCrc", crc).setMaxResults(1).getResultList();
        
        return (String) list.get(0);
    }
    */
    
    
    @Override
    public Set<String> getBestClients() {
        List<String> resultList = em.createQuery("SELECT res.carRenter FROM CarRentalCompany crc JOIN crc.cars car JOIN car.reservations res GROUP BY res.carRenter ORDER BY COUNT(res) DESC").getResultList();
        return new HashSet<String>(resultList);
        
    }
    

    @Override
    public CarType getMostPupularCarType(String crcName, int year) {
        
        CarRentalCompany crc = em.find(CarRentalCompany.class, crcName);
        
        
        String start = "1/1/"+Integer.toString(year);
        String end = "31/12/"+Integer.toString(year);
        
        
        
        Date startDate = new Date();
        try {
            startDate = DATE_FORMAT.parse(start);
        } catch (ParseException ex) {
            Logger.getLogger(ManagerSession.class.getName()).log(Level.SEVERE, null, ex);
        }
        Date endDate = new Date();
        try {
            DATE_FORMAT.parse(end);
        } catch (ParseException ex) {
            Logger.getLogger(ManagerSession.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        List list = em.createQuery("SELECT ct FROM CarRentalCompany crc JOIN crc.carTypes ct JOIN crc.cars car JOIN car.reservations res WHERE crc= :givenCrc AND car.type=ct AND res.startDate BETWEEN :givenStart AND :givenEnd GROUP BY ct ORDER BY COUNT(ct) DESC")
                .setParameter("givenCrc", crc).setParameter("givenStart", startDate).setParameter("givenEnd", endDate).setMaxResults(1).getResultList();
        if(list.isEmpty()){
            System.out.println("LIST HEEFT GEEN ENKELE RESULT, FOUTE QUERY?");
            return null;
        }
        return (CarType) list.get(0);
    }

    @Override
    public CarType getCheapestCarTypeAvailable(Date startDate, Date endDate, String region) {
        
        
        List list = em.createQuery("SELECT ct FROM CarRentalCompany crc JOIN crc.carTypes ct JOIN crc.cars car JOIN car.reservations res WHERE (:givenRegion IN crc.regions) AND (car.type=ct) AND (:givenStart NOT BETWEEN res.startDate and res.endDate) "
                + "AND (:givenEnd NOT BETWEEN res.startDate AND res.endDate) ORDER BY ct.rentalPricePerDay ASC")
                .setParameter("givenRegion", region).setParameter("givenStart", startDate).setParameter("givenEnd", endDate).setMaxResults(1).getResultList();
        
        
        
        return (CarType) list.get(0);
        
    }
    
    @Override
    public int getNbReservationsBy(String clientName) {
        List list = em.createQuery("SELECT res FROM CarRentalCompany crc JOIN crc.cars car JOIN car.reservations res WHERE res.carRenter=:givenClient").setParameter("givenClient", clientName).getResultList();
    
        return list.size();
    }
    
    private String userName;
    private String carRentalCompanyName;

    @Override
    public void setUserName(String name) {
        userName = name;
    }

    @Override
    public void setCarRentalCompanyName(String carRentalName) {
        carRentalCompanyName = carRentalName;
    }

    
    
    

    

    
    
    
    

}